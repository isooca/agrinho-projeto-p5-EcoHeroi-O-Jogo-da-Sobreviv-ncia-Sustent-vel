// Definindo variáveis globais
let boneco;
let plantas = [];
let temperatura = 8;
let totalArvores = 5;

function setup() {
  createCanvas(400, 400);
  boneco = new Jardineiro(width / 2, height - 50);
}

function draw() {
  // Gradiente de cor de fundo: do marrom para o verde, conforme as árvores aumentam
  let t = map(totalArvores, 0, 100, 0, 1);
  let corFundo = lerpColor(color(216,47, 0), color(215, 239, 208), t);
  background(corFundo);

  mostrarInformacoes();

  temperatura += 0.1;

  boneco.atualizar();
  boneco.mostrar();

  verificarFimDeJogo();

  // Mostra todas as árvores plantadas
  for (let arvore of plantas) {
    arvore.mostrar();
  }
}

// Mostrar informações na tela
function mostrarInformacoes() {
  textSize(16);
  fill(0);
  text("🌡️ Temperatura: " + temperatura.toFixed(2) + "°C", 10, 40);
  text("🌳 Árvores plantadas: " + totalArvores, 10, 50);
  text("🕹️ Use as setas para mover e S/N para plantar", 10, 80);
}

// Verifica se o jogo acabou
function verificarFimDeJogo() {
  if (totalArvores > temperatura) {
    mostrarMensagemDeVitoria();
  } else if (temperatura > 50) {
    mostrarMensagemDeDerrota();
  }
}

// Mensagem de vitória
function mostrarMensagemDeVitoria() {
  textSize(20);
  fill(0, 120, 0);
  text("🎉 Você venceu! Plantou muitas árvores!", 30, 200);
  noLoop();
}

// Mensagem de derrota
function mostrarMensagemDeDerrota() {
  textSize(20);
  fill(255, 0, 0);
  text("💀 Você perdeu! Temperatura muito alta!", 30, 100);
  noLoop();
}

// Classe Jardineiro
class Jardineiro {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.emoji = "👲";
    this.velocidade = 4;
  }

  atualizar() {
    if (keyIsDown(LEFT_ARROW)) this.x -= this.velocidade;
    if (keyIsDown(RIGHT_ARROW)) this.x += this.velocidade;
    if (keyIsDown(UP_ARROW)) this.y -= this.velocidade;
    if (keyIsDown(DOWN_ARROW)) this.y += this.velocidade;
  }

  mostrar() {
    textSize(32);
    text(this.emoji, this.x, this.y);
  }
}

// Classe Árvore
class Arvore {
  constructor(x, y) {
    this.x = x;
    this.y = y;
  }

  mostrar() {
    fill(34, 139, 34); // verde escuro
    ellipse(this.x, this.y, 20, 20);
  }
}

// Plantar árvore ao apertar S ou N
function keyPressed() {
  if (key === "s" || key === "n") {
    let arvore = new Arvore(boneco.x, boneco.y);
    plantas.push(arvore);
    totalArvores++;
    temperatura -= 3;
    if (temperatura < 0) temperatura = 0;
  }
}